__version_info__ = (1, 18, 4)
__version__ = '.'.join(map(str, __version_info__))
